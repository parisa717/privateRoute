import { createContext , useState } from "react";

export const UserContext = createContext(null);

const UserContextProvider = (props) => {
    const [isLogin, setlogin] = useState(true)
 
  const login = () => {
   setlogin(true)
  };

  const logout = () => {
      setlogin(false)
  };

 
  return (
    <UserContext.Provider value={{ login, logout, isLogin }}>
      {props.children}
    </UserContext.Provider>
  );
};

export default UserContextProvider;
