import "./App.css";
import {useState} from 'react'
import { Link, Route, Switch } from "react-router-dom";
import Home from "./home";
import About from "./About";
import UserContextProvider from "./UserContext";
import PrivateRoute from "./PrivateRoute";

function App() {
  
  return (
    <div>
      <nav>
        <ul>
          <Link to="/home">home</Link>
          <Link to="/about">about</Link>
        </ul>
      </nav>
      <Switch>
        <UserContextProvider >
          <Route exact path="/home" component={Home} />
          <PrivateRoute exact path="/about" component={About} />
        </UserContextProvider>
      </Switch>
    </div>
  );
}

export default App;
