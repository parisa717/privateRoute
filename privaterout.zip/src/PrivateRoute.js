import React,{useContext} from 'react'
import { Redirect, Route } from 'react-router-dom'
import { UserContext } from './UserContext'

const PrivateRoute = ({component: Componen , ...rest}) => {
    const {isLogin} = useContext(UserContext)
    
    return (
      <Route {...rest} render={props => (
          isLogin ? <Componen {...props} /> : <Redirect to='/home' />
      )}/>
    )
}

export default PrivateRoute
