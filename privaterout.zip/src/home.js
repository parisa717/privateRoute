import React,{useContext} from 'react'
import { UserContext } from './UserContext'

const Home = () => {
    const {isLogin,login ,logout} = useContext(UserContext)
    console.log(isLogin)
    return (
        <div>
             Home
            <button onClick={login}>login</button>
            <button onClick={logout}>logout</button>

        </div>
    )
}

export default Home
